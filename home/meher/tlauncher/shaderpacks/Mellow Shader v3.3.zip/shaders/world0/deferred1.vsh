#version 400 compatibility
#define DIMENSION_OVERWORLD

#include "/program/deferred1.vsh"