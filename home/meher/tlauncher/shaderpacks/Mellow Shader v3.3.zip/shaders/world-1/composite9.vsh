#version 400 compatibility
#define DIMENSION_NETHER

#include "/program/composite9.vsh"